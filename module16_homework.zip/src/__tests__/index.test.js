import { getPercents } from "../index.js";

describe("test percent", () => {
  it("30 percent from 200 equally 60", () => {
    const result = getPercents(30, 200);
    expect(result).toBe(60);
  }),
  it("30 percent from 200 equally 0", () => {
    const result = getPercents(30, 200);
    expect(result).toBe(0);
  });
  it("20 percent from 500 equally 100", () => {
    const result = getPercents(20, 500);
    expect(result).toBe(100);
  });
  it("20 percent from 500 equally 140", () => {
    const result = getPercents(20, 500);
    expect(result).toBe(140);
  });
});

describe("test correctly percent", () => {
  it("0 percent equally message", () => {
    const result = getPercents(0, 200);
    expect(result).toBe(`Вы ввели 0 процент`);
  }),
  it("0 percent equally message", () => {
    const result = getPercents(20, 200);
    expect(result).toBe(`Вы ввели 20 процент`);
  })
});

describe("test correctly percent", () => {
  it("minus percent equally message", () => {
    const result = getPercents(-20, 200);
    expect(result).toBe(`Вы ввели отрицательный процент`);
  })
});

describe("test not a number", () => {
  it("test not a number equally boolean", () => {
    const result = getPercents("a", "b");
    expect(result).toBe(true);
  }),
  it("test not a number equally boolean", () => {
    const result = getPercents("a", 10);
    expect(result).toBe(true);
  }),
  it("test not a number equally boolean", () => {
    const result = getPercents(10, "b");
    expect(result).toBe(true);
  })
});
