export function getPercents(percent, number) {
    let result = 0;
    if (percent === 0) {return result = `Вы ввели ${percent} процент`;}
    if (percent < 0) {return result = `Вы ввели отрицательный процент`;}
    if (typeof(percent) !== 'number' || typeof(number) !== 'number' ) {
        return result = false;
    }
    result = number / 100 * percent;
	return result;
}

//alert( getPercents(30, 200) );